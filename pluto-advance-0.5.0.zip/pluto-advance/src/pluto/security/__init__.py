"""Pluto security layer."""
