"""Pluto voice layer."""
